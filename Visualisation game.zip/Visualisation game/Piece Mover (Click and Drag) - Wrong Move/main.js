const table = document.querySelector('#table');
const cells = table.getElementsByTagName('td');
var chessPiece = document.createElement('div');
var previousSquare;
var previousPiece;
var highlighted = false;
var currentSquare;
var isDragging = false;

chessPiece.classList.add('red-ball');
cells[0].appendChild(chessPiece);
chessPiece.setAttribute("draggable", true);

chessPiece = document.createElement('div');
chessPiece.classList.add('green-ball');
cells[1].appendChild(chessPiece);
chessPiece.setAttribute("draggable", true);

chessPieces = table.getElementsByTagName('div');

function undo (currentSquare, previousSquare, chessPiece, previousPiece) {
  currentSquare.classList.toggle("incorrect")
  setTimeout(() => {
    if (typeof previousPiece != "undefined") {
      currentSquare.appendChild(previousPiece);
    }
    previousSquare.appendChild(chessPiece);
    currentSquare.classList.toggle("incorrect")
  }, 300);
}

document.addEventListener("DOMContentLoaded", function() {
  for (var i = 0; i < cells.length; i++) {
    cells[i].addEventListener("click", function() {
      if (highlighted == false && this.hasChildNodes()) {
        chessPiece = this.childNodes[0]; //I could also use this.firstChild()
        this.classList.toggle("highlight");
        highlighted = !highlighted;
        previousSquare = this;
      } else if (highlighted == true) {
        if (this.hasChildNodes()) {
          previousPiece = this.firstChild;
          this.removeChild(previousPiece);
        }
        currentSquare = this
        currentSquare.appendChild(chessPiece);
        previousSquare.classList.toggle("highlight");
        highlighted = false;
        undo (currentSquare, previousSquare, chessPiece, previousPiece)
      }
    });

    cells[i].addEventListener("dragover", function(event) {
      event.preventDefault();
      if(highlighted == false) {
        previousSquare.classList.toggle("highlight");
        highlighted = true;
      }
    });

    cells[i].addEventListener("drop", function(event) {
      event.preventDefault();
      previousSquare.classList.toggle("highlight");
      if (this.hasChildNodes()) {
        previousPiece = this.firstChild;
        this.removeChild(previousPiece);
      }
      highlighted = false;
      if (!this.contains(chessPiece)) {
        this.appendChild(chessPiece);
      }
      currentSquare = this;
      undo (currentSquare, previousSquare, chessPiece, previousPiece)

    });
  }

  for (var j = 0; j < chessPieces.length; j++) {
    chessPieces[j].addEventListener("dragstart", function(event) {
      if (highlighted == true) {
        previousSquare.classList.toggle("highlight");
        highlighted = false;
      }
      isDragging = true;
      chessPiece = this;
      previousSquare = chessPiece.closest("td");
    });

    }
});

window.addEventListener('mousedown', (event) => {
  // Check if the right mouse button was pressed
  if (event.button === 2) {
    // Check if the drag operation is in progress
    if (isDragging) {
      console.log('Right-click while dragging:', event.clientX, event.clientY);
    } else {
      console.log('Right-click:', event.clientX, event.clientY);
    }
  }
});

window.addEventListener('mousemove', (event) => {
  // Check if the right mouse button was pressed
  if (event.button === 2) {
    // Check if the drag operation is in progress
    if (isDragging) {
      console.log('Right-click while dragging:', event.clientX, event.clientY);
    } else {
      console.log('Right-click:', event.clientX, event.clientY);
    }
  }
});
