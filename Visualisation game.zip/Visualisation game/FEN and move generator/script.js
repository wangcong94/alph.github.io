const questionArray = [];

// generate a random FEN, and next few moves
function generateQuestion(num_of_questions) {
  const chess = new Chess();
  // Set the board to the initial position
  chess.reset();
  // Make a random number of random moves
  const moves = Math.floor(Math.random() * 100);
  for (let i = 0; i < moves; i++) {
    const legalMoves = chess.moves();
    chess.move(legalMoves[Math.floor(Math.random() * legalMoves.length)]);
    // Check if the game is over. In that case, reset board.
    if (chess.game_over()) {
      chess.reset();
    }
  }
  for (let i = 0; i < num_of_questions; i++) {
    const fen = chess.fen();
    // Check whose turn it is
    const turn = chess.turn();
    // Get a random next legal move
    var randomMove = chess.moves()[Math.floor(Math.random() * chess.moves().length)];
    // Make the first move
    chess.move(randomMove);
    // Get the destination square of the last move
    var lastMove = chess.history({verbose: true}).slice(-1)[0];
    console.log("last move is ", lastMove);
    console.log(lastMove.color);
    questionArray.push({move: randomMove, turn: turn, fen: fen, origSquare: lastMove.from, destSquare: lastMove.to});
  }
}

//
function generateTarget() {
  if (questionArray.length === 0) {
    generateQuestion(3);
  }
  const question = questionArray.shift();
  var turnMessage = "";
  readFEN(question.fen);
  if (question.turn === "w") {
    var turnMessage = "White to move: ";
  } else if (question.turn === "b") {
    var turnMessage = "Black to move: ";
  }
  // populate target textbox
  document.getElementById("target").textContent = turnMessage + question.move;
  return {
    origFEN: question.fen,
    origSquare: question.origSquare,
    destSquare: question.destSquare
  }
}
