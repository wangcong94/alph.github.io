"""
import tkinter as tk
from tkinter import filedialog

# Create a Tkinter root window (this is required to use the file dialog)
root = tk.Tk()
root.withdraw()  # Hide the root window

# Use the file dialog to get the filename
filename = filedialog.askopenfilename()
"""
filename = "pgn/testPGN.pgn"
# Open the selected file and read it in parts
with open(filename, 'r') as file:
    result = []
    leftover = ''
    while len(result) < 2000:
        part = file.read(1000)  # Read 1000 characters at a time
        if not part:
            break  # End of file
        part = leftover + part  # Append any leftover data from the previous chunk
        parts = part.split('\n\n')
        leftover = parts.pop()  # Keep any leftover data for the next chunk
        result.extend(parts)

pgns = []
i = 0
print ("[")
while i<len(result):
    if i%2 ==1:
        clean = result[i].replace("\n", " ")
        print('"' + clean + '",')
    i = i + 1
print ("]")
       
