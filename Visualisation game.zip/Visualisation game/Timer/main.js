function toggleScoreAlert(scoreAlert) {
  if (scoreAlert == null) return
  document.getElementById('scoreAlert').classList.toggle('active');
  document.getElementById('overlay').classList.toggle('active');
}

function setTimer(timeLeft) {
  var minutes = Math.floor(timeLeft / 60);
  var seconds = (timeLeft % 60).toString().padStart(2, '0');
  document.getElementById('timer').textContent = `${minutes}:${seconds}`;
}

function togglePlay_Stop() {
  let playButtonIcon = document.getElementById('playButtonIcon');
  let playButton = document.getElementById('playButton');
  playButtonIcon.classList.toggle("fa-play");
  playButtonIcon.classList.toggle("fa-stop");
  if (playButton.getAttribute("data-button-state") == "play") {
    playButton.setAttribute("data-button-state", "stop");
  } else {
    playButton.setAttribute("data-button-state", "play");
  }
}

function startTimer(timeLeft) {
  const originalTime = timeLeft;
  setTimer(timeLeft);
  timer = setInterval(() => {
    if (document.getElementById('playButton').getAttribute("data-button-state")=="play") {
      clearInterval(timer);
      return;
    }
    timeLeft--;
    setTimer(timeLeft);
    // Check if time is up
    if (timeLeft === 0) {
      setTimer(originalTime);
      toggleScoreAlert(scoreAlert);
      togglePlay_Stop();
      clearInterval(timer);
    }
  }, 1000);
}

setTimer(3);

document.getElementById('close-button').addEventListener('click', () => {
    toggleScoreAlert(scoreAlert);
  });

// Add a click event listener to the play button
document.getElementById('playButton').addEventListener('click', () => {
  let buttonState = document.getElementById('playButton').getAttribute("data-button-state")
  togglePlay_Stop();
  // Update the button text and function based on the current button state
  if (buttonState === "play") {
    // if current buttonState is "play", pressing the button starts it.
    startTimer(3);
  } else {
    setTimer(3);
    toggleScoreAlert(scoreAlert);
  }
});
