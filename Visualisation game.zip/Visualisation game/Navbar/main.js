document.getElementById('menuIcon').addEventListener('click', () => {
    openNav();
  });

/* Set the width of the side navigation to 250px */
function openNav() {
  document.getElementById("mySidenav").classList.remove("hidden");
  setTimeout(function () {
      document.getElementById("mySidenav").classList.add("show");
  }, 1);
}

document.getElementById('closebtn').addEventListener('click', () => {
    closeNav();
  });

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("mySidenav").classList.remove("show");
  setTimeout(function () {
      document.getElementById("mySidenav").classList.add("hidden");
  }, 300);
}
