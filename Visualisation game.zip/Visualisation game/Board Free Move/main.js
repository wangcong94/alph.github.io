const board = document.getElementById("board");
const squares = board.getElementsByTagName('td');
var chessPiece = document.createElement('div');
var targetSquare;
var correct = 0;
var incorrect = 0;
var previousSquare;
var previousPiece;
var highlighted = false; // I used to call "highlighted" "secondClick", but I realised calling it highlighted makes more sense
var currentSquare;
var chessPieces = board.getElementsByTagName('div');;
var destSquare;
var fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

function readFEN(fen) {
  var piecePlacement = fen.split(" ")[0];
  var rows = piecePlacement.split("/");
  for (var i = 1; i <= rows.length; i++) {
    var row = rows[i-1];
    var file = 0;
    for (var j = 0; j < row.length; j++) {
      var character = row[j];
      if (isNaN(character)) {
        // character is a piece
        let files = ["a", "b", "c", "d", "e", "f", "g", "h"];
        let squareName = files[file] + i;
        // convert fen piece notation to ("colour" + "piece")
        // Check if the letter is uppercase
        if (character == character.toLowerCase()) {
          // Add "w" to the letter
          character = "w" + character;
        } else {
          // Add "b" to the letter
          character = "b" + character.toLowerCase();;
        }
        generatePiece(character, squareName);
        file++;
      } else {
        // character is a number
        file += parseInt(character);
      }
    }
  }
}

readFEN(fen);

// generate piece on board given (pieceName, squareName)
function generatePiece(pieceName, squareName) {
  chessPiece = document.createElement('div');
  chessPiece.classList.add(pieceName);
  let square = document.querySelector("[id$='"+squareName+"']");
  square.appendChild(chessPiece);
  chessPiece.setAttribute("draggable", true);
  enablePieceDrag(chessPiece);
}

function flipBoard() {
  // flipping the board
  board.classList.toggle("flipped");
  // flipping the chesspieces
  for (let i = 0; i < chessPieces.length; i++) {
    chessPieces[i].classList.toggle(("flipped"));
  };
  let flipButton = document.getElementById("flip-button");
  let flipButtonText = flipButton.textContent;
  // flipping the labels
  flipButton.textContent = flipButton.getAttribute("data-text");
  flipButton.setAttribute("data-text", flipButtonText);
  let labels = document.querySelectorAll(".label");
  labels.forEach(label => label.classList.toggle("hidden"));
  outerSquares.forEach((outerSquare)=>{
    let rank_white = outerSquare.getAttribute("data-top");
    let rank_black = outerSquare.getAttribute("data-top-reverse");
    outerSquare.setAttribute("data-top",rank_black);
    outerSquare.setAttribute("data-top-reverse",rank_white);
    let file_white = outerSquare.getAttribute("data-bottom");
    let file_black = outerSquare.getAttribute("data-bottom-reverse");
    outerSquare.setAttribute("data-bottom",file_black);
    outerSquare.setAttribute("data-bottom-reverse",file_white);
    outerSquare.classList.toggle("rotate");
  });

}

function toggleLabels() {
  outerSquares.forEach((outerSquare)=>{
    outerSquare.classList.toggle("show");
  });
}

// colour squares of td in #board using this very clever formula I found on the internet
// I am using this because if I colour it in CSS, board colour becomes more specific than class selectors, which I want to avoid
function colourSquares() {
  let tds = document.querySelectorAll("#board td");
  tds.forEach((td, i) => {
    if(parseInt((i/8)+i)%2 == 1) {
      td.classList.toggle("darkSquare");
    }
  });
}

// chess pieces drag logic. As chess pieces are created dynamically, I need to refresh this function everytime I generate a new chessPiece
function enablePieceDrag(thisPiece) {
  thisPiece.addEventListener("dragstart", function(event) {
    if (highlighted == true) {
      previousSquare.classList.toggle("highlight");
      highlighted = false;
    }
    chessPiece = this;
    previousSquare = chessPiece.closest("td");
  });
}


// ------------------------ Main Starts Here -----------------------------------------
colourSquares();

//piece move logic
document.addEventListener("DOMContentLoaded", function() {
  for (var i = 0; i < squares.length; i++) {
    squares[i].addEventListener("click", function() {
      if (highlighted == false && this.hasChildNodes()) {
        chessPiece = this.childNodes[0]; //I could also use this.firstChild()
        this.classList.toggle("highlight");
        highlighted = !highlighted;
        previousSquare = this;

      } else if (highlighted == true) {
        if (this.hasChildNodes()) {
          previousPiece = this.firstChild;
          this.removeChild(previousPiece);
        }
        currentSquare = this
        currentSquare.appendChild(chessPiece);
        previousSquare.classList.toggle("highlight");
        highlighted = false;
      }
    });

    squares[i].addEventListener("dragover", function(event) {
      event.preventDefault();
      if(highlighted == false) {
        previousSquare.classList.toggle("highlight");
        highlighted = true;
      }
    });

    squares[i].addEventListener("drop", function(event) {
      event.preventDefault();
      previousSquare.classList.toggle("highlight");
      if (this.hasChildNodes()) {
        previousPiece = this.firstChild;
        this.removeChild(previousPiece);
      }
      highlighted = false;
      if (!this.contains(chessPiece)) {
        this.appendChild(chessPiece);
      }
      currentSquare = this;
    });
  }
});

const flipButton = document.getElementById("flip-button");
const outerSquares = document.querySelectorAll("[id^='outerSquare']");
flipButton.addEventListener("click", flipBoard);

const toggleButton = document.getElementById("toggle-button");
toggleButton.addEventListener("click", toggleLabels);
