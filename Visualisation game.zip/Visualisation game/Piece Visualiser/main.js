const board = document.getElementById("board");
const squares = board.getElementsByTagName('td');
var chessPiece = document.createElement('div');
var targetSquare;
var correct = 0;
var incorrect = 0;
var previousSquare;
var previousPiece;
var highlighted = false; // was "secondClick"
var currentSquare;
var chessPieces = board.getElementsByTagName('div');
var destSquare;
const flipButton = document.getElementById("flip-button");
const outerSquares = document.querySelectorAll("[id^='outerSquare']");
const toggleButton = document.getElementById("toggle-button");

// generate a random chess piece and the square to move to
function generateTarget() {
  // generate a random square
  let files = ["a", "b", "c", "d", "e", "f", "g", "h"];
  let targetSelector1 = Math.floor(Math.random() * 8);
  let targetSelector2 = Math.floor(Math.random() * 8);
  let targetFile = files[targetSelector1];
  let targetRank = targetSelector2 + 1;
  targetSquare = targetFile + targetRank;

  // generate a random piece to place into the target square
  if (targetRank == 1 || targetRank == 8) {
    var pieces = ["r", "n", "b", "q", "k", "q"];
  } else {
    var pieces = ["r", "n", "b", "q", "k", "p"];
  }
  let colours = ["w", "b"];
  targetSelector1 = Math.floor(Math.random() * 6);
  targetSelector2 = Math.floor(Math.random() * 2);
  let piece = pieces[targetSelector1];
  let colour = colours[targetSelector2];
  // call function to generate random piece
  generatePiece(colour+piece, targetSquare);

  // using the Chess.js library, give a random legal move
  const chess = new Chess();
  chess.clear();
  chess.put({ type: piece, color: colour}, targetSquare);
  if (colour == "b") {set_turn(chess, "b");}
  let legalMoves = chess.moves({square: targetSquare});
  let randomMove = legalMoves[Math.floor(Math.random() * legalMoves.length)];
  chess.move(randomMove);
  // Get the last move made
  var lastMove = chess.history({verbose: true}).pop();
  // Get the destination square of the last move
  destSquare = lastMove.to;
  document.getElementById("target").textContent = randomMove.replace("#","");
}

// generate piece on board given (pieceName, squareName)
function generatePiece(pieceName, squareName) {
  chessPiece = document.createElement('div');
  chessPiece.classList.add(pieceName);
  let square = document.querySelector("[id$='"+squareName+"']");
  square.appendChild(chessPiece);
  if (flipButton.textContent == "Black") {
    chessPiece.classList.toggle("flipped");
  }
  chessPiece.setAttribute("draggable", true);
  enablePieceDrag(chessPiece);
}

function set_turn(chess, color) {
  var tokens = chess.fen().split(' ');
  tokens[1] = color;
  chess.load(tokens.join(' '));
}

function undo () {
  currentSquare.classList.toggle("incorrect")
  setTimeout(() => {
    if (typeof previousPiece != "undefined") {
      currentSquare.appendChild(previousPiece);
    }
    previousSquare.appendChild(chessPiece);
    currentSquare.classList.toggle("incorrect")
  }, 300);
}

// checks the user click with the correct square
function checkGuess() {
  var result = "Correct!";
  guess = currentSquare.id.split("-")[1];
  if (guess === destSquare) {
    correct++;
    document.getElementById("result_wrapper").classList.add("correct");
    setTimeout(() => {
      document.getElementById("result_wrapper").classList.remove("correct");
    }, 500);
  } else {
    incorrect++;
    result = "Incorrect"
    document.getElementById("result_wrapper").classList.add("incorrect");
    setTimeout(() => {
      document.getElementById("result_wrapper").classList.remove("incorrect");
    }, 500);
  }
  document.getElementById("result").textContent = result;
  document.getElementById("scoreboard").textContent = "Correct: " + correct + " Incorrect: " + incorrect;
  return result;
}


function flipBoard() {
  // flipping the board
  board.classList.toggle("flipped");
  // flipping the chesspieces
  for (let i = 0; i < chessPieces.length; i++) {
    chessPieces[i].classList.toggle(("flipped"));
  };
  let flipButton = document.getElementById("flip-button");
  let flipButtonText = flipButton.textContent;
  // flipping the labels
  flipButton.textContent = flipButton.getAttribute("data-text");
  flipButton.setAttribute("data-text", flipButtonText);
  let labels = document.querySelectorAll(".label");
  labels.forEach(label => label.classList.toggle("hidden"));
  outerSquares.forEach((outerSquare)=>{
    let rank_white = outerSquare.getAttribute("data-top");
    let rank_black = outerSquare.getAttribute("data-top-reverse");
    outerSquare.setAttribute("data-top",rank_black);
    outerSquare.setAttribute("data-top-reverse",rank_white);
    let file_white = outerSquare.getAttribute("data-bottom");
    let file_black = outerSquare.getAttribute("data-bottom-reverse");
    outerSquare.setAttribute("data-bottom",file_black);
    outerSquare.setAttribute("data-bottom-reverse",file_white);
    outerSquare.classList.toggle("rotate");
  });

}

function toggleLabels() {
  outerSquares.forEach((outerSquare)=>{
    outerSquare.classList.toggle("show");
  });
}

// colour squares of td in #board using this very clever formula I found on the internet
// I am using this because if I colour it in CSS, board colour becomes more specific than class selectors, which I want to avoid
function colourSquares() {
  let tds = document.querySelectorAll("#board td");
  tds.forEach((td, i) => {
    if(parseInt((i/8)+i)%2 == 1) {
      td.classList.toggle("darkSquare");
    }
  });
}

// chess pieces drag logic. As chess pieces are created dynamically, I need to refresh this function everytime I generate a new chessPiece
function enablePieceDrag(thisPiece) {
  thisPiece.addEventListener("dragstart", function(event) {
    if (highlighted == true) {
      previousSquare.classList.toggle("highlight");
      highlighted = false;
    }
    chessPiece = this;
    previousSquare = chessPiece.closest("td");
  });
}


// ------------------------ Main Starts Here -----------------------------------------
generateTarget();
colourSquares();

//piece move logic
document.addEventListener("DOMContentLoaded", function() {
  for (var i = 0; i < squares.length; i++) {
    squares[i].addEventListener("click", function() {
      if (highlighted == false && this.hasChildNodes()) {
        chessPiece = this.childNodes[0]; //I could also use this.firstChild()
        this.classList.toggle("highlight");
        highlighted = !highlighted;
        previousSquare = this;
      } else if (highlighted == true) {
        if (this.hasChildNodes()) {
          previousPiece = this.firstChild;
          this.removeChild(previousPiece);
        }
        currentSquare = this
        currentSquare.appendChild(chessPiece);
        previousSquare.classList.toggle("highlight");
        highlighted = false;
        if (currentSquare.id != previousSquare.id) {
          if (checkGuess()=="Correct!") {
            setTimeout(function () {
              currentSquare.removeChild(currentSquare.firstChild);
              generateTarget();
            }, 300);

          } else {
            undo();
          }
        }
      }
    });

    squares[i].addEventListener("dragover", function(event) {
      event.preventDefault();
      if(highlighted == false) {
        previousSquare.classList.toggle("highlight");
        highlighted = true;
      }
    });

    squares[i].addEventListener("drop", function(event) {
      event.preventDefault();
      previousSquare.classList.toggle("highlight");
      if (this.hasChildNodes()) {
        previousPiece = this.firstChild;
        this.removeChild(previousPiece);
      }
      highlighted = false;
      if (!this.contains(chessPiece)) {
        this.appendChild(chessPiece);
      }
      currentSquare = this;
      if (currentSquare.id != previousSquare.id) {
        if (checkGuess()=="Correct!") {
          setTimeout(function () {
          currentSquare.removeChild(currentSquare.firstChild);
          generateTarget();
        }, 300);
        } else {
          undo();
        }
      }
    });
  }
});


flipButton.addEventListener("click", flipBoard);
toggleButton.addEventListener("click", toggleLabels);
