
let games = getData();
const questionArray = [];

console.log(games.length);

// generate an FEN, and next few moves
function generateQuestion(num_of_questions) {
  const chess = new Chess();
  chess.reset();
  game = games[Math.floor(Math.random()*games.length)];
  chess.loadPgn(game);
  moveNumber = 3 + Math.floor(Math.random()*(chess.history().length - num_of_questions - 3));
  for (let i = 0; i < num_of_questions; i++) {
    // Get the destination square of the last move
    var lastMove = chess.history({verbose: true})[moveNumber + i];
    console.log("last move is ", lastMove);
    console.log(lastMove.fen);
    questionArray.push({move: lastMove.san, turn: lastMove.color, fen: lastMove.fen, origSquare: lastMove.from, destSquare: lastMove.to});
  }
}

generateQuestion(3);
console.log(questionArray);
