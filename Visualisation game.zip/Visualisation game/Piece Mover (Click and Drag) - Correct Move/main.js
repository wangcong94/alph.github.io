const table = document.querySelector('#table');
const squares = table.getElementsByTagName('td');
var chessPiece = document.createElement('div');
var previousSquare;
var previousPiece;
var highlighted = false;
var currentSquare;

chessPiece.classList.add('red-ball');
squares[0].appendChild(chessPiece);
chessPiece.setAttribute("draggable", true);

chessPiece = document.createElement('div');
chessPiece.classList.add('green-ball');
squares[1].appendChild(chessPiece);
chessPiece.setAttribute("draggable", true);

chessPieces = table.getElementsByTagName('div');

function undo (currentSquare, previousSquare, chessPiece, previousPiece) {
  currentSquare.classList.toggle("incorrect")
  setTimeout(() => {
    if (typeof previousPiece != "undefined") {
      currentSquare.appendChild(previousPiece);
    }
    previousSquare.appendChild(chessPiece);
    currentSquare.classList.toggle("incorrect")
  }, 300);
}

document.addEventListener("DOMContentLoaded", function() {
  for (var i = 0; i < squares.length; i++) {
    squares[i].addEventListener("click", function() {
      if (highlighted == false && this.hasChildNodes()) {
        chessPiece = this.childNodes[0]; //I could also use this.firstChild()
        this.classList.toggle("highlight");
        highlighted = !highlighted;
        previousSquare = this;
      } else if (highlighted == true) {
        if (this.hasChildNodes()) {
          previousPiece = this.firstChild;
          this.removeChild(previousPiece);
        }
        currentSquare = this
        currentSquare.appendChild(chessPiece);
        previousSquare.classList.toggle("highlight");
        highlighted = false;
      }
    });

    squares[i].addEventListener("dragover", function(event) {
      event.preventDefault();
      if(highlighted == false) {
        previousSquare.classList.toggle("highlight");
        highlighted = true;
      }
    });

    squares[i].addEventListener("drop", function(event) {
      event.preventDefault();
      previousSquare.classList.toggle("highlight");
      if (this.hasChildNodes()) {
        previousPiece = this.firstChild;
        this.removeChild(previousPiece);
      }
      highlighted = false;
      if (!this.contains(chessPiece)) {
        this.appendChild(chessPiece);
      }
      currentSquare = this;
    });
  }

  for (var j = 0; j < chessPieces.length; j++) {
    console.log(chessPieces);
    chessPieces[j].addEventListener("dragstart", function(event) {
      if (highlighted == true) {
        previousSquare.classList.toggle("highlight");
        highlighted = false;
      }
      chessPiece = this;
      previousSquare = chessPiece.closest("td");
    });
    }
});
